package com.example.konversinilai;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class OutputActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_output);

        TextView txtNama  = (TextView) findViewById(R.id.outuser);
        TextView txtNim   = (TextView) findViewById(R.id.outnim);
        TextView txtHasil = (TextView) findViewById(R.id.outnilai);

        Bundle extras = getIntent().getExtras();

        String NAMA = "NAMA";
        String nama = extras.getString(NAMA);
        txtNama.setText(String.format(": %s", nama));

        String NIM = "NIM";
        String nim = extras.getString(NIM);
        txtNim.setText(String.format(": %s", nim));

        String NILAI = "NILAI";
        String nilai = extras.getString(NILAI);
        txtHasil.setText(String.format(": %s", nilai));
    }
}